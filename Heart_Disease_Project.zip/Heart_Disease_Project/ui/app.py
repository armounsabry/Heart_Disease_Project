import streamlit as st
import pandas as pd
import joblib

# Load saved pipeline
model = joblib.load("models/best_model.pkl")

st.title("Heart Disease Prediction App")

# User inputs
age = st.number_input("Age", min_value=1, max_value=120, step=1)
sex = st.selectbox("Sex", ["male", "female"])
cp = st.selectbox("Chest Pain Type (cp)", [0, 1, 2, 3])
trestbps = st.number_input("Resting Blood Pressure", min_value=50, max_value=250, step=1)
chol = st.number_input("Cholesterol", min_value=100, max_value=600, step=1)
fbs = st.selectbox("Fasting Blood Sugar > 120 mg/dl", [0, 1])
restecg = st.selectbox("Resting ECG", [0, 1, 2])
thalach = st.number_input("Maximum Heart Rate", min_value=50, max_value=250, step=1)
exang = st.selectbox("Exercise Induced Angina", [0, 1])
oldpeak = st.number_input("ST Depression", min_value=0.0, max_value=10.0, step=0.1)
slope = st.selectbox("Slope", [0, 1, 2])
ca = st.selectbox("Number of Major Vessels (ca)", [0, 1, 2, 3, 4])
thal = st.selectbox("Thalassemia", [0, 1, 2, 3])

# Convert inputs to a dataframe
input_data = pd.DataFrame([[age, 1 if sex=="male" else 0, cp, trestbps, chol, fbs,
                            restecg, thalach, exang, oldpeak, slope, ca, thal]],
                          columns=["age","sex","cp","trestbps","chol","fbs","restecg",
                                   "thalach","exang","oldpeak","slope","ca","thal"])

# Prediction button
if st.button("Predict"):
    pred = model.predict(input_data)
    if pred[0] == 1:
        st.error("You may have heart disease!")
    else:
        st.success("You are healthy!")

# Optional: Show prediction probability
if st.checkbox("Show Prediction Probability"):
    pred_prob = model.predict_proba(input_data)
    st.write("Probability of Heart Disease:", round(pred_prob[0][1]*100, 2), "%")