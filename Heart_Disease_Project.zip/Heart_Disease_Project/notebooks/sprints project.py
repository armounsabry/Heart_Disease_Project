import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
import streamlit as st
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import RFE, SelectKBest, chi2
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_curve, auc, classification_report
from sklearn.cluster import KMeans, AgglomerativeClustering
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn.metrics import adjusted_rand_score
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV

st.title("Heart Disease Prediction App")

df = pd.read_csv(r"C:\Users\fadya\Downloads\heart.csv")

print("Loaded rows:", len(df))
print("Columns:", df.columns.tolist()) 
print("Missing per column:\n", df.isnull().sum())

df.hist(figsize=(15, 12), bins=20, edgecolor='black')
plt.suptitle("Histograms of Features", fontsize=16)
#plt.show()

plt.figure(figsize=(12, 8))
corr = df.corr()
sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f", cbar=True)
plt.title("Correlation Heatmap", fontsize=16)
#plt.show()

target = df['target']
df = df.drop('target', axis=1)

num_cols = ['age', 'trestbps', 'chol', 'thalach', 'oldpeak', 'ca']
cat_cols = ['sex', 'cp', 'fbs', 'restecg', 'exang', 'slope', 'thal']

scaler = MinMaxScaler()
df[num_cols] = scaler.fit_transform(df[num_cols])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', MinMaxScaler(), num_cols),
        ('cat', OneHotEncoder(), cat_cols)
    ]
)

plt.figure(figsize=(15, 10))
df.boxplot()
plt.title("Boxplots of Features", fontsize=16)
plt.xticks(rotation=45)
#plt.show()

pca = PCA()
X_pca = pca.fit_transform(df)
explained_var = pca.explained_variance_ratio_

cumulative_var = np.cumsum(explained_var)
plt.figure(figsize=(8, 5))
plt.plot(range(1, len(cumulative_var) + 1), cumulative_var, marker='o', linestyle='--')  # <- comma between x and y
plt.xlabel("Number of Principal Components")
plt.ylabel("Cumulative Explained Variance")
plt.title("Explained Variance vs. Number of Components")
plt.grid(True)
plt.ylim(0, 1.05)
plt.axhline(y=0.95, color='gray', linestyle=':', linewidth=1)  # optional 95% line
#plt.show()
plt.figure(figsize=(8, 6))
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=target, cmap='coolwarm', edgecolor='k', alpha=0.7)
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.title("PCA - First Two Components")
plt.colorbar(label="Target")
#plt.show()

rf = RandomForestClassifier(random_state=42)
rf.fit(df, target)

rfe_selector = RFE(estimator=RandomForestClassifier(random_state=42), n_features_to_select=8)
rfe_selector.fit(df, target)
rfe_support = rfe_selector.support_
rfe_features = df.columns[rfe_support]
print("Selected by RFE:", list(rfe_features))

chi2_selector = SelectKBest(score_func=chi2, k=8)
chi2_selector.fit(df, target)
chi2_support = chi2_selector.get_support()
chi2_features = df.columns[chi2_support]
print("Selected by Chi-Square:", list(chi2_features))

    # --------------------------------------------------------------------------------------------
    #                                         supervised Learning
    # --------------------------------------------------------------------------------------------
print("Columns in dataset:", df.columns.tolist())

X_train, X_test, y_train, y_test = train_test_split(df, target, test_size=0.2, random_state=42, stratify=target)

models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
        "Decision Tree": DecisionTreeClassifier(random_state=42),
        "Random Forest": RandomForestClassifier(random_state=42),
        "SVM": SVC(probability=True, random_state=42)  # probability=True for ROC curve
    }

results = {}

plt.figure(figsize=(8, 6))

for name, model in models.items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        y_prob = model.predict_proba(X_test)[:, 1]  # for ROC curve
        
        acc = accuracy_score(y_test, y_pred)
        prec = precision_score(y_test, y_pred)
        rec = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        
        results[name] = [acc, prec, rec, f1]
        
        # Print classification report
        print(f"\n{name} Classification Report:\n")
        print(classification_report(y_test, y_pred))
        
        # ROC Curve
        fpr, tpr, _ = roc_curve(y_test, y_prob)
        roc_auc = auc(fpr, tpr)
        plt.plot(fpr, tpr, label=f"{name} (AUC = {roc_auc:.2f})")

results_df = pd.DataFrame(results, index=["Accuracy", "Precision", "Recall", "F1-Score"])
print("\nPerformance Summary:\n", results_df)

plt.plot([0, 1], [0, 1], 'k--')  # diagonal line
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve Comparison")
plt.legend(loc="lower right")
#plt.show()

    # --------------------------------------------------------------------------------------------
    #                                       unsupervised Learning
    # --------------------------------------------------------------------------------------------
inertia = []
K = range(1, 11)

for k in K:
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
        kmeans.fit(df)
        inertia.append(kmeans.inertia_)

plt.figure(figsize=(8, 5))
plt.plot(K, inertia, marker="o", linestyle="--")
plt.xlabel("Number of Clusters (K)")
plt.ylabel("Inertia")
plt.title("Elbow Method for Optimal K")
#plt.show()

    # Let's assume optimal K=2 (since heart disease = yes/no)
kmeans = KMeans(n_clusters=2, random_state=42, n_init=10)
clusters_kmeans = kmeans.fit_predict(df)

    # Compare with actual labels
ari_kmeans = adjusted_rand_score(target, clusters_kmeans)
print(f"\nAdjusted Rand Index (K-Means vs Target): {ari_kmeans:.3f}")


plt.figure(figsize=(12, 6))
Z = linkage(df, method="ward")
dendrogram(Z, truncate_mode="lastp", p=30, leaf_rotation=45, leaf_font_size=10)
plt.title("Hierarchical Clustering Dendrogram")
plt.xlabel("Sample Index or (Cluster Size)")
plt.ylabel("Distance")
#plt.show()

    # Fit Hierarchical clustering with 2 clusters
hc = AgglomerativeClustering(n_clusters=2, metric="euclidean", linkage="ward")
clusters_hc = hc.fit_predict(df)

    # Compare with actual labels
ari_hc = adjusted_rand_score(target, clusters_hc)
print(f"Adjusted Rand Index (Hierarchical vs Target): {ari_hc:.3f}")


plt.figure(figsize=(8, 6))
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=clusters_kmeans, cmap="viridis", alpha=0.7, edgecolor="k")
plt.title("K-Means Clustering (PCA Projection)")
plt.xlabel("PC1")
plt.ylabel("PC2")
#plt.show()
plt.figure(figsize=(8, 6))
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=clusters_hc, cmap="plasma", alpha=0.7, edgecolor="k")
plt.title("Hierarchical Clustering (PCA Projection)")
plt.xlabel("PC1")
plt.ylabel("PC2")
#plt.show()





# ------------------------------
# Hyperparameter Optimization
# ------------------------------

# Random Forest Optimization
rf_params = {
    'n_estimators': [50, 100, 200],
    'max_depth': [None, 5, 10, 20],
    'min_samples_split': [2, 5, 10]
}

rf_grid = GridSearchCV(RandomForestClassifier(random_state=42),
                       rf_params, cv=5, scoring='accuracy', n_jobs=-1)
rf_grid.fit(X_train, y_train)

print("\nBest Random Forest Params:", rf_grid.best_params_)
print("Best Random Forest Score:", rf_grid.best_score_)

# SVM Optimization
svm_params = {
    'C': [0.1, 1, 10],
    'kernel': ['linear', 'rbf', 'poly'],
    'gamma': ['scale', 'auto']
}

svm_random = RandomizedSearchCV(SVC(probability=True, random_state=42),
                                svm_params, n_iter=5, cv=5,
                                scoring='accuracy', n_jobs=-1, random_state=42)
svm_random.fit(X_train, y_train)

print("\nBest SVM Params:", svm_random.best_params_)
print("Best SVM Score:", svm_random.best_score_)

# Logistic Regression Optimization
log_params = {
    'C': [0.01, 0.1, 1, 10],
    'penalty': ['l2'],
    'solver': ['lbfgs', 'liblinear']
}

log_grid = GridSearchCV(LogisticRegression(max_iter=1000, random_state=42),
                        log_params, cv=5, scoring='accuracy', n_jobs=-1)
log_grid.fit(X_train, y_train)

print("\nBest Logistic Regression Params:", log_grid.best_params_)
print("Best Logistic Regression Score:", log_grid.best_score_)


# ------------------------------
# Compare Optimized Models vs Baseline
# ------------------------------
optimized_models = {
    "Random Forest Optimized": rf_grid.best_estimator_,
    "SVM Optimized": svm_random.best_estimator_,
    "Logistic Regression Optimized": log_grid.best_estimator_
}

opt_results = {}

for name, model in optimized_models.items():
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    opt_results[name] = [acc, prec, rec, f1]
    print(f"\n{name} Classification Report:\n", classification_report(y_test, y_pred))

opt_results_df = pd.DataFrame(opt_results, index=["Accuracy", "Precision", "Recall", "F1-Score"])

# Compare baseline vs optimized
print("\nBaseline Models Performance:\n", results_df)
print("\nOptimized Models Performance:\n", opt_results_df)




final_pipeline = Pipeline(steps=[
    ("preprocessor", preprocessor),
    ("model", RandomForestClassifier(
        n_estimators=200,
        max_depth=6,
        random_state=42
    ))
])

final_pipeline.fit(X_train, y_train)


joblib.dump(final_pipeline, "best_model.pkl")
print(" Model pipeline saved as best_model.pkl")



model = joblib.load("best_model.pkl")

data = {
    "age": [45],
    "sex": [1],
    "trestbps": [130],
    "chol": [250],
    "fbs": [0],
    "thalach": [160],
    "exang": [0],
    "oldpeak": [2.3],
    "ca": [0],
    "cp": [2],
    "restecg": [1],
    "slope": [2],
    "thal": [3]
}
df = pd.DataFrame(data)

pred = model.predict(df)
print("Prediction:", pred[0])





age = st.number_input("Age", min_value=1, max_value=120, step=1)
sex = st.selectbox("Sex", ["male", "female"])
cp = st.selectbox("Chest Pain Type (cp)", [0, 1, 2, 3])
trestbps = st.number_input("Resting Blood Pressure", min_value=50, max_value=250, step=1)
chol = st.number_input("Cholesterol", min_value=100, max_value=600, step=1)
fbs = st.selectbox("Fasting Blood Sugar > 120 mg/dl", [0, 1])
restecg = st.selectbox("Resting ECG", [0, 1, 2])
thalach = st.number_input("Maximum Heart Rate", min_value=50, max_value=250, step=1)
exang = st.selectbox("Exercise Induced Angina", [0, 1])
oldpeak = st.number_input("ST Depression", min_value=0.0, max_value=10.0, step=0.1)
slope = st.selectbox("Slope", [0, 1, 2])
ca = st.selectbox("Number of Major Vessels (ca)", [0, 1, 2, 3, 4])
thal = st.selectbox("Thalassemia", [0, 1, 2, 3])

input_data = pd.DataFrame([[age, 1 if sex=="male" else 0, cp, trestbps, chol, fbs,
                            restecg, thalach, exang, oldpeak, slope, ca, thal]],
                          columns=["age","sex","cp","trestbps","chol","fbs","restecg",
                                   "thalach","exang","oldpeak","slope","ca","thal"])

if st.button("Predict"):
    pred = model.predict(input_data)
    if pred[0] == 1:
        st.error("you may have heart disease!")
    else:
        st.success("you are healthy!")